/*
 * @Author       : LQ
 * @Description  :
 * @version      : 1.0
 * @Date         : 2021-08-20 16:44:21
 * @LastAuthor   : LQ
 * @lastTime     : 2021-08-20 17:04:32
 * @FilePath     : /u-view2.0/uview-ui/libs/config/props/formItem.js
 */
export default {
    // formItem 组件
    formItem: {
        label: '',
        prop: '',
        rules: [],
        borderBottom: '',
        labelPosition: '',
        labelWidth: '',
        rightIcon: '',
        leftIcon: '',
        required: false,
        leftIconStyle: '',
    }
}
