<template>
	<view class="content">
		<up-search placeholder="搜索经典" bgColor="#e3e3e3" v-model="keyword"></up-search>
		<up-swiper
				v-if="bannerList.length"
		        :list="bannerList"
				keyName="image"
				showTitle="true"
				radius="8"
				:autoplay="true"
				height="160"
		        @change="change"
		        @click="click"
		    ></up-swiper>
		<up-notice-bar text="示例,非正式数据" bgColor=""></up-notice-bar>
		<view class="list">
			<up-waterfall v-model="flowList">
				<template v-slot:left="{leftList}">
					<view class="demo-warter" v-for="(item, index) in leftList" :key="index" @click="goDrtail(item)">
						<up-lazy-load threshold="-450" border-radius="10" :image="item.img" :index="index"></up-lazy-load>
						<!-- 这里编写您的内容，item为您传递给v-model的数组元素 -->
						<view class="demo-title">{{item.title}}</view>
						<view class="demo-time">{{item.times}}元</view>
						<view class="demo-tag">
							<view class="demo-tag-owner">
								{{ item.tag[0] }}
							</view>
							<view class="demo-tag-text">
								{{ item.tag[1] }}
							</view>
						</view>
						<view class="isDot" v-if="item.isDot">
							{{ item.isDot }}
						</view>
					</view>
				</template>
				<template v-slot:right="{rightList}">
					<view class="demo-warter" v-for="(item, index) in rightList" :key="index" @click="goDrtail(item)">
						<up-lazy-load threshold="-450" border-radius="10" :image="item.img" :index="index"></up-lazy-load>
						<!-- 这里编写您的内容，item为您传递给v-model的数组元素 -->
						<view class="demo-title">{{item.title}}</view>
						<view class="demo-time">{{item.times}}元</view>
						<view class="demo-tag">
							<view class="demo-tag-owner">
								{{ item.tag[0] }}
							</view>
							<view class="demo-tag-text">
								{{ item.tag[1] }}
							</view>
						</view>
						<view class="isDot" v-if="item.isDot">
							{{ item.isDot }}
						</view>
					</view>
				</template>
			</up-waterfall>
		</view>
		<view class="topClass" v-if="showTopBtn" @click="toTop">
			<up-icon name="arrow-upward" color="#fff" size="20px"></up-icon>
		</view>
	</view>
</template>

<script setup>
	import { ref, reactive } from 'vue'
	import { getBanner, getHomeList } from '../../api/api.js'
	import { onLoad, onReachBottom, onPageScroll } from '@dcloudio/uni-app'
	
	const keyword = ref('')
	//轮播图数据
	const bannerList = ref([])
	//瀑布流数据
	const flowList = ref([])
	//滚动是否显示
	const showTopBtn = ref(false)

	onLoad(() => {
		// 发起请求
		// 获取轮播图
		getBanner().then(res => {
			// 将获取到的轮播图列表赋值给bannerList
			bannerList.value = res.bannerList
		}),
		// 获取首页列表
		getHomeList().then(res => {
			// 将获取到的首页列表赋值给flowList
			flowList.value = res
		})
	})
	
	// 监听页面滚动到底部事件
	onReachBottom(() => {
		// 发起请求
		getHomeList().then(res => {
			console.log(res, 'getHomeList')
			flowList.value = flowList.value.concat(res)
		})
	})
	
	onPageScroll((e) => {
		// 监听页面滚动事件
		if (e.scrollTop > 300) {
			// 如果滚动距离大于300
			showTopBtn.value = true
			// 显示返回顶部按钮
		} else {
			showTopBtn.value = false
			// 否则隐藏返回顶部按钮
		}
	})
	
	// 跳转到详情页
	const goDrtail = (item) => {
		// 将item对象转换为JSON字符串
		const can = JSON.stringify(item)
		// 使用uni.navigateTo方法跳转到详情页，并将item对象作为参数传递
		uni.navigateTo({
			url: `/pages/detail/detail?item=${encodeURIComponent(can)}`
		})
	}
	
	//定义点击后跳转到顶部
	const toTop = () => {
		uni.pageScrollTo({
			scrollTop: 0,
			duration: 300
		})
	}
</script>

//页面样式
<style>
	page {
		background-color: rgb(240, 240, 240);
	}
</style>

<style lang="scss" scoped>
	.content {
		padding: 20rpx 20rpx;
	}
	.topClass {
		position: fixed;
		bottom: 120rpx;
		right: 30rpx;
		width: 44rpx;
		height: 44rpx;
		background-color: rgba(0,0,0,0.5);
		padding: 20rpx;
		border-radius: 50%;
		text-align: center;
		line-height: 44rpx;
		display: flex;
		justify-content: center;
		align-items: center;
	}

	.list {
		margin-top: 30rpx;
		}
		.demo-warter {
			position: relative;
			margin: 10rpx 10rpx 10rpx 0;
			background-color: #fff;
			border-radius: 16rpx;
			padding: 16rpx;
			.demo-title {
				font-size: 30rpx;
				margin-top: 10rpx;
				color: #303133;
			}
			.demo-time {
				font-size: 24rpx;
				margin-top: 10rpx;
				color: #777;
			}
			.demo-tag {
				display: flex;
				margin-top: 10rpx;
				.demo-tag-owner,
				.demo-tag-text {
					display: flex;
					align-items: center;
					font-size: 20rpx;
					border-radius: 50rpx;
					padding: 4rpx 14rpx;
				}
				.demo-tag-owner {
					color: #ffaa00;
					border: 1px solid rgb(252, 163, 129);
				}
				.demo-tag-text {
					border: 1px solid #00aaff;
					color: #00aaff;
					margin-left: 20rpx;
			}
		}
		.isDot {
			position: absolute;
			top: 20rpx;
			right: 20rpx;
			font-size: 24rpx;
			line-height: 32rpx;
			background-color: #ff0000;
			color: #ffffff;
			text-align: center;
			border-radius: 10rpx;
			padding: 4rpx 10rpx;
		}
	}

	
</style>
