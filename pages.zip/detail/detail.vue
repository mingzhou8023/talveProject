<template>
	<view class="detail">
		<view>
									<!-- 8个0透明色 -->
		    <up-navbar title="" bg-color="#00000000" :autoBack="true" left-icon-color="#fff"></up-navbar>
			<view class="d-con">
				<image :src="detail.dt.img" mode="aspectFill"></image>
				<view class="d-content">
					<view class="j-con">
						<view class="tit" style="display: flex;">
							<text class="txt" style="margin-right: 7px;font-size: 17px;">{{ detail.dt.title }}</text>
							<up-tag text="5A级景区" size="mini" shape="circle"></up-tag>
						</view>
						<view class="jj">
							<view style="font-weight: 700;font-size: 14px;">景区介绍</view>
							<view class="nr">{{ detail.dt.intorduce }}</view>
						</view>
						<view class="j-con">
							<view class="jj">
								<text style="font-weight: 700;font-size: 14px;">开放时间</text>
								<view class="nr">{{ detail.dt.times }}</view>
							</view>
						</view>
						<view class="j-con ls">
							<view class="tit" style="font-size: 34rpx;">游玩推荐</view>
							<view class="jj tj-list">
								<view class="item" v-for="(item, index) in projectList" :key="index" @click="goLine(item)">
									<image :src="item.url" mode="aspectFill"></image>
									<view class="topFixed">
										{{ item.tag }}
									</view>
									<view class="infos">
										<view class="tit">{{ item.title }}</view>
										<view class="desc">
											<up-icon name="map" color="#9c9c9c" size="16"></up-icon>
											<text class="text">{{ item.desc }}</text>
										</view>
									</view>
								</view>
							</view>
						</view>
					</view>
				</view>
			</view>
		</view>
	</view>
</template>

<script setup>
	import { onLoad } from '@dcloudio/uni-app'
	import { ref, reactive } from 'vue'
	import { getPlayList } from '../../api/api.js'
	
	// 定义一个响应式对象，用于存储详情信息
	const detail = reactive({
		dt: ''
	})
	
	// 定义一个goLine函数，用于跳转到详情页
	const goLine = (item) => {
		// 使用uni.navigateTo方法跳转到详情页，并将item对象作为参数传递
		uni.navigateTo({
			url: `/pages/line/line?id=${item.id}`
		})
	}
	
	// 定义一个响应式数组，用于存储项目列表
	const projectList = ref([])
	
	onLoad((options) => {
		// 调用getPlayList函数，获取播放列表
		getPlayList().then(res => {
			// 将获取到的播放列表赋值给projectList
			projectList.value = res
		})
		// 解码options.item，并将其转换为JSON对象
		detail.dt = JSON.parse(decodeURIComponent(options.item))
	})
	
</script>

<style lang="scss" scoped>
	.detail {
		background-color: #f5f5f5;
		.d-con {
			image {
				width: 100%;
				height: 600rpx;
			}
			.d-content {
				width: 100%;
				height: 700rpx;
				margin-top: -40rpx;
				background-color: #fff;
				padding: 35rpx 30rpx;
				box-sizing: border-box;
				border-top-left-radius: 30rpx;
				border-top-right-radius: 30rpx;
				position: relative;
				z-index: 9;
				.j-con {
					margin-bottom: 30rpx;
					.tit {
						font-size: 34rpx;
						font-weight: 700;
						color: #111;
						margin-bottom: 30rpx;
					}
					.jj {
						.nr {
							font-size: 26rpx;
							color: #8a8a8a;
							line-height: 40rpx;
						}
					}
					.tj-list {
						display: flex;
						flex-wrap: wrap;
						justify-content: space-between;
						.item {
							width: 48%;
							margin-bottom: 20rpx;
							box-shadow: 1px 2px 3px #e5e5e5;
							position: relative;
							overflow: hidden;
							border-top-left-radius: 20rpx;
							border-top-right-radius: 20rpx;
							.topFixed {
								position: absolute;
								top: 0;
								left: 0;
								border-top-left-radius: 20rpx;
								border-bottom-right-radius: 20rpx;
								background-color: #ffaa7f;
								color: #fff;
								text-align: center;
								font-size: 22rpx;
								padding: 5rpx 20rpx;
								box-sizing: border-box;
							}
							image {
								width: 100%;
								height: 200rpx;
							}
							.infos {
								padding: 10rpx 15rpx;
								.tit {
									font-size: 28rpx;
									font-weight: 700;
									color: #111;
									margin-bottom: 15rpx;
									text-overflow: ellipsis;
								}
								.desc {
									display: flex;
									justify-content: flex-start;
									align-items: center;
									.text {
										fonst-size: 26rpx;
										color: #8a8a8a;
									}
									
								}
							}
									
						}
					}
				}
			}
		}
	}
</style>
