<template>
	<view class="content">
		<view class="topBox">
			<view class="setBox">
				<view class="set-left">
					<up-icon name="order" size="30" color="#fff"></up-icon>
					<view class="txt">签到</view>
				</view>
				<view class="set-right">
					<up-icon name="chat" size="30" color="#fff"></up-icon>
					<up-icon name="setting" size="30" color="#fff"></up-icon>
				</view>
			</view>
			<view class="users" @click="setFun">
				<view class="user-top">
					<template v-if="!userInfo.nickName">
						<image src="../../static/tt.jpg" mode="aspectFill"></image>
						<view class="tit">
							注册 / 登录
						</view>
					</template>
					<template v-else>
						<image :src="userInfo.avatarUrl" mode="aspectFill"></image>
						<view class="tit">
							{{ userInfo.nickName }}
						</view>
					</template>
				</view>
				<view class="user-bottom">
					<view class="user-item">
						<view class="num">11</view>
						<view class="user-tit">点赞</view>
					</view>
					<view class="user-item">
						<view class="num">11</view>
						<view class="user-tit">喜欢</view>
					</view>
					<view class="user-item">
						<view class="num">11</view>
						<view class="user-tit">浏览</view>
					</view>
					<view class="user-item">
						<view class="num">11</view>
						<view class="user-tit">收藏</view>
					</view>
				</view>
			</view>
		</view>
		<view class="listBox">
			<view class="lists">
				<view class="list-item">
					<image class="icon-left" src="/static/tabbar/user1.png" mode=""></image>
					<view class="tit-left">个人信息</view>
					<image class="icon-right" src="/static/tabbar/enter.png" mode=""></image>
				</view>
				<view class="list-item">
					<image class="icon-left" src="/static/tabbar/cart_empty.png" mode=""></image>
					<view class="tit-left">我的购物车</view>
					<image class="icon-right" src="/static/tabbar/enter.png" mode=""></image>
				</view>
				<view class="list-item">
					<image class="icon-left" src="/static/tabbar/userSend.png" mode=""></image>
					<view class="tit-left">用户反馈</view>
					<image class="icon-right" src="/static/tabbar/enter.png" mode=""></image>
				</view>
				<view class="list-item">
					<image class="icon-left" src="/static/tabbar/email.png" mode=""></image>
					<view class="tit-left">我的邮件</view>
					<image class="icon-right" src="/static/tabbar/enter.png" mode=""></image>
				</view>
				<view class="list-item">
					<image class="icon-left" src="/static/tabbar/seng.png" mode=""></image>
					<view class="tit-left">分享有礼</view>
					<image class="icon-right" src="/static/tabbar/enter.png" mode=""></image>
				</view>
			</view>
		</view>
		<up-popup closeable :show="show" @close="close" round="20">
			<view class="popup">
				<view class="title">获取您的昵称和头像</view>
				<view class="flex">
					<view class="label">获取用户头像：</view>
					<button class="avatar-warpper" open-type="chooseAvatar" @chooseavatar="onChooseavatar">
						<image class="avatar" :src="userInfo.avatarUrl" mode="aspectFill"></image>
					</button>
				</view>
				<view class="flex">
					<view class="label">获取用户昵称：</view>
					<input type="nickname"  @input="changeName"/>
				</view>
				<button size="default" type="primary" @click="userSubmit">确定</button>
			</view>
		</up-popup>
	</view>
</template>

<script setup>
	import { ref, reactive } from 'vue'
	import { onLoad } from '@dcloudio/uni-app'
	import { login, getUserInfo } from '../../api/api.js'
	
	onLoad(async () => {
		//免登录逻辑
		if (uni.getStorageSync('token') && !uni.getStorageSync('userInfo')) {
			const { avatarUrl, nickName } = await getUserInfo()
				userInfo.avatarUrl = avatarUrl
				userInfo.nickName = nickName
		} else if (uni.getStorageSync('token') && uni.getStorageSync('userInfo')) {
			const { avatarUrl, nickName } = JSON.parse(uni.getStorageSync('userInfo'))
			userInfo.avatarUrl = avatarUrl
			userInfo.nickName = nickName
		}
	})
	
	const extraIcon1 = reactive({
		color: '#666666',
		size: '22',
		type: 'auth'
	})
	
	const extraIcon2 = reactive({
		color: '#666666',
		size: '22',
		type: 'cart'
	})
	const extraIcon3 = reactive({
		color: '#666666',
		size: '22',
		type: 'chatboxes'
	})
	const extraIcon4 = reactive({
		color: '#666666',
		size: '22',
		type: 'email'
	})
	const extraIcon5 = reactive({
		color: '#666666',
		size: '22',
		type: 'gift'
	})


	const userInfo = reactive({
		nickName: '',
		avatarUrl: ''
	})
	
	// 定义一个响应式变量show，初始值为false
	const show = ref(false)
	
	// 定义一个关闭函数close
	const close = () => {
		show.value = false
	}
	
	// 点击用户头像昵称
	const userSubmit = () => {
		// 将userInfo对象转换为JSON字符串，并存储在本地缓存中
		uni.setStorageSync('userInfo', JSON.stringify(userInfo))
		show.value = false
	}
	
	//获取用户头像
	const onChooseavatar = (e) => {
		userInfo.avatarUrl = e.detail.avatarUrl;
	}
	
	// 获取用户昵称
	const changeName = (e) => {
		userInfo.nickName = e.detail.value;

	}

	
	//用户授权登录
	const setFun = () => {
		uni.showModal({
		  	title: '温馨提示',
			content: '亲，授权微信登陆后才能正常使用小程序',
			success: (res) => {
				if (res.confirm) {
					uni.login({
						success: async (data) => {
							console.log(data)
							try {
							    const { token } = await login(data.code); // 确保 login 方法正确调用
							    console.log(token, 'token')
								uni.setStorageSync('token', token)
							} catch (error) {
							    console.error('登录失败:', error);
							}
							//根据token获取用户信息
							const { avatarUrl, nickName } = await getUserInfo()
							userInfo.avatarUrl = avatarUrl
							userInfo.nickName = nickName
							show.value = true
						}
					})
				}
			}
		})
	}

</script>

<style lang="scss" scoped>
	.content {
		height: 100vh;
		background-color: #f5f5f5;
	}
	.listBox {
		margin: 0rpx 30rpx 0 30rpx;
		background-color: #fff;
		.list-item {
			display: flex;
			align-items: center;
			width: 100%;
			height: 80rpx;
			border-bottom: 2px solid #ececec;
			.icon-left {
				width: 40rpx;
				height: 40rpx;
				margin: 0rpx 20rpx 0 20rpx;
			}
			.tit-left{
				flex: 1;
				font-size: 30rpx;
				color: #333;
				line-height: 80rpx;
			}
			.icon-right {
				width: 30rpx;
				height: 30rpx;
				margin-top: 0rpx;
				margin-right: 20rpx;
			}
		}
	}
	.topBox {
		width: 100%;
		position: relative;
		z-index: 1;
		overflow: hidden;
		padding: 40rpx 20rpx 40rpx;
		box-sizing: border-box;
		
	}
	.topBox::after {
			content: '';
			position: absolute;
			top: 0;
			left: -20%;
			width: 140%;
			height: 200px;
			background-color: #00aaff;
			border-radius: 0 0 50% 50%;
			z-index: -1;
		}
		.setBox {
			display: flex;
			justify-content: space-between;
			align-items: center;
				.set-left {
					display: flex;
					justify-content: space-between;
					align-items: center;
					width: 18%;
					.txt {
						font-size: 30rpx;
						color: #fff;
					}
				}
				.set-right {
					display: flex;
					align-items: center;
					justify-content: space-between;
					width: 100rpx;
				}
		}
		.users {
			margin-top: 35rpx;
			padding: 30rpx;
			box-sizing: border-box;
			height: 280rpx;
			background-color: #fff;
			box-shadow: 1px 10rpx 20rpx #ececec;
			border-radius: 16rpx;
			.user-top {
				display: flex;
				justify-content: flex-start;
				align-items: center;
				margin-bottom: 30rpx;
				image {
					width: 100rpx;
					height: 100rpx;
					border-radius: 50%;
					margin-right: 20rpx;
				}
				.tit {
					font-size: 30rpx;
					font-weight: 700;
					color: #333;
				}
			}
			.user-bottom {
					display: flex;
					justify-content: space-around;
					align-items: center;
					.user-item {
						text-align: center;
						.num {
							font-size: 33rpx;
							font-weight: 700;
							corlor: #000;
						}
						.user-tit {
							font-size: 26rpx;
							color: #757575;
							margin-bottom: 10rpx;
						}
					}
			}
		}
		.popup {
			padding: 20rpx;
			border-radius: 20rpx 20rpx 0 0;
			.title {
					font-size: 40rpx;
					margin-bottom: 20rpx;
					text-align: center;
			}
			.flex {
				display: flex;
				justify-content: flex-start;
				align-items: center;
				border-bottom: 1px solid #f5f5f5;
				padding: 24rpx 0;
			}
			image {
				width: 70rpx;
				height: 70rpx;
			}
			.avatar-warpper {
				border: none;
				border-radius: 10rpx;
				width: 70rpx;
				height: 70rpx;
				margin-left: 20rpx;
				padding: 0;
			}
		}
</style>
