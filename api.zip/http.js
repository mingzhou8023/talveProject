//接口公共前缀地址
let baseUrl = ''

//通过环境来判断是否为Moke
// 判断当前环境是否为开发环境
if (process.env.NODE_ENV === 'development') {
  // 如果是开发环境，将baseUrl设置为本地地址
  // baseUrl = 'https://localhost:5173/api'
  baseUrl = 'https://m1.apifoxmock.com/m1/4728220-0-default/api'
} else {
  // 如果不是开发环境，将baseUrl设置为线上地址
	baseUrl = 'https://m1.apifoxmock.com/m1/4728220-0-default/api'
}

const http = {
  get(url, data) {
    return new Promise((resolve, reject) => {
      uni.request({
        url: baseUrl + url,
        data,
        method: 'GET',
        header: {
          'token': uni.getStorageSync('token') || ''
        },
        success: (res) => {
          //statusCode为200时，请求成功
          if (res.statusCode === 200) {
            if (res.data.code === 1) {
              //请求成功，返回数据
              resolve(res.data.data);
            } else if (res.data.code === 0) {
              //请求失败，弹出提示框
              uni.showToast({
                title: res.data.msg,
                icon: 'none'
              });
              //返回错误信息
              reject(res.data.msg);
            }
          }
        },
        fail: () => {
          // 请求失败时，弹出提示框
          uni.showToast({
            title: '服务器请求异常',
            icon: 'none'
          })
        }
      })
    })
  },
   post(url, data) {
      return new Promise((resolve, reject) => {
        uni.request({
          url: baseUrl + url,
          data,
          method: 'POST',
          header: {
            'token': uni.getStorageSync('token') || '',
          },
          success: (res) => {
            // statusCode为200时，请求成功
            if (res.statusCode === 200) {
              if (res.data.code === 1) {
                // 请求成功，返回数据
                resolve(res.data.data);
              } else if (res.data.code === 0) {
                // 请求失败，弹出提示框
                uni.showToast({
                  title: res.data.msg,
                  icon: 'none',
                });
                // 返回错误信息
                reject(res.data.msg);
              }
            }
          },
          fail: () => {
            // 请求失败时，弹出提示框
            uni.showToast({
              title: '服务器请求异常',
              icon: 'none',
            })
          }
        })
      })
    }
}

export default http;