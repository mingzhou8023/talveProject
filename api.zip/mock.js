import Mock from 'mockjs'
import pageApi from './mockData/pageApi'

// Mock.setup({ timeout: '200-600' })

Mock.mock(/api\/user\/getBanner/, 'get', pageApi.getBanner())