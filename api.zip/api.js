import http from "./http.js";


//首页banner
export const getBanner = () => http.get("/user/getBanner");

//首页瀑布流数据
export const getHomeList = () => http.get("/user/getHomeList");

//登录用户授权
export const login = (code) => http.post("/login", { code });

//获取用户信息
export const getUserInfo = () => http.get("/getUserInfo");

//获取游玩项目
export const getPlayList = () => http.get("/detail/project");

//获取游玩项目详情
export const getPlayDetail = (id) => http.get('/project/info', id);

//获取我的喜欢列表
export const getMyLikeList = () => http.get('/like/list');
